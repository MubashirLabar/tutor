# tutor-backend


### `npm start`

Runs the app api in the development mode.<br>
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

### `http://localhost:3000/api/user post url` 

### { "first_name": "test", "last_name": "test", "email":"test2@gmail.com", "password":"978883", "user_type":"client"}